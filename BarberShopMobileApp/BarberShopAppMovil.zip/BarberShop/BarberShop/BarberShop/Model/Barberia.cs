﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;

namespace BarberShop.Model
{
    public class Barberia: INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChange([CallerMemberName] string nombre = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nombre));
        }

        private int id;
        public int Id
        {
            get { return id; }
            set { id = value; OnPropertyChange(); }
        }

        private string nombre;
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; OnPropertyChange(); }
        }

        private string direccion;

        public string Direccion
        {
            get { return direccion; }
            set { direccion = value; OnPropertyChange(); }
        }

        private string telefono;

        public string Telefono
        {
            get { return telefono; }
            set { telefono = value; OnPropertyChange(); }
        }

        private string correo;

        public string Correo
        {
            get { return correo; }
            set { correo = value; OnPropertyChange(); }
        }

        private string horario;

        public string Horario
        {
            get { return horario; }
            set { horario = value; OnPropertyChange(); }
        }

        private string estado;

        public string Estado
        {
            get { return estado; }
            set { estado = value; OnPropertyChange(); }
        }

        private string visualizacion;

        public string Visualizacion
        {
            get { return visualizacion; }
            set { visualizacion = value; OnPropertyChange(); }
        }
    }
}
