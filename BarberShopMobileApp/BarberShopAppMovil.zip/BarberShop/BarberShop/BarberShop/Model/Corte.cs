﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;

namespace BarberShop.Model
{
    public class Corte : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChange([CallerMemberName] string nombre = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nombre));
        }

        private int id;

        public int Id
        {
            get { return id; }
            set { id = value; OnPropertyChange(); }
        }

        private string nombre;

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; OnPropertyChange(); }
        }

        private string visualizacion;

        public string Visualizacion
        {
            get { return visualizacion; }
            set { visualizacion = value; OnPropertyChange(); }
        }
    }
}
