﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;

namespace BarberShop.Model
{
    public class Cita : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChange([CallerMemberName] string nombre = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nombre));
        }

        private int id;

        public int Id
        {
            get { return id; }
            set { id = value; OnPropertyChange(); }
        }

        private string fecha;

        public string Fecha
        {
            get { return fecha; }
            set { fecha = value; OnPropertyChange(); }
        }

        private string hora;

        public string Hora
        {
            get { return hora; }
            set { hora = value; OnPropertyChange(); }
        }

        private string estado;

        public string Estado
        {
            get { return estado; }
            set { estado = value; OnPropertyChange(); }
        }

        private Corte corte;

        public Corte Corte
        {
            get { return corte; }
            set { corte = value; OnPropertyChange(); }
        }

        private Barbero barbero;

        public Barbero Barbero
        {
            get { return barbero; }
            set { barbero = value; OnPropertyChange(); }
        }

        private Barberia barberia;

        public Barberia Barberia
        {
            get { return barberia; }
            set { barberia = value; OnPropertyChange(); }
        }
    }
}
