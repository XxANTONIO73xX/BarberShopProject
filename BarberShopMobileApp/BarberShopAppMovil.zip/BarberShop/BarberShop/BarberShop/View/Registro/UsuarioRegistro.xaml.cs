﻿using BarberShop.ViewModel.VMMain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BarberShop.View.Registro
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class UsuarioRegistro : ContentPage
    {
        public UsuarioRegistro()
        {
            InitializeComponent();
            BindingContext = new VMUsuarioRegistro(Navigation);
        }
    }
}