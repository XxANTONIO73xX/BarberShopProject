﻿using BarberShop.Helpers;
using BarberShop.View.Sesion;
using BarberShop.ViewModel.VMMain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BarberShop.View.Main
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ConsultarCitas : ContentPage
    {
        public ConsultarCitas()
        {
            validar();
            InitializeComponent();
            BindingContext = new VMConsultarCitas(Navigation);
        }
        public async void validar()
        {
            if (Settings.Token == null)
            {
                await DisplayAlert("Error", "Tu sesion ya expiro", "Iniciar Sesión");
                await Navigation.PushAsync(new Login());
            }

        }
    }
}