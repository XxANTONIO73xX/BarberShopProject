﻿using BarberShop.Helpers;
using BarberShop.Model;
using BarberShop.View.Main;
using BarberShop.View.Sesion;
using BarberShop.ViewModel.VMMain;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BarberShop.View.Main
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AgendarCitas : ContentPage
    {
        public AgendarCitas()
        {
            validar();
            InitializeComponent();
            BindingContext = new VMAgendarCitas(Navigation);
            
        }

        private async void ListaCorte_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Corte corte = e.CurrentSelection.FirstOrDefault() as Corte;
            Cita Cita = new Cita();
            Cita.Corte = corte;
            await Navigation.PushAsync(new FormularioCita(Cita));
        }

        public async void validar()
        {
            if (Settings.Token == null)
            {
                await DisplayAlert("Error", "Tu sesion ya expiro", "Iniciar Sesión");
                await Navigation.PushAsync(new Login());
            }

        }
    }
}