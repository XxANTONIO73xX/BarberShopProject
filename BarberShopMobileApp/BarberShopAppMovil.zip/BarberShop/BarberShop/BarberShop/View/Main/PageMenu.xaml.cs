﻿using BarberShop.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BarberShop.View.Sesion;
using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration;
using Xamarin.Forms.PlatformConfiguration.AndroidSpecific;
using Xamarin.Forms.Xaml;

namespace BarberShop.View.Main
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PageMenu : Xamarin.Forms.TabbedPage
    {
        public PageMenu()
        {
            validar();
            InitializeComponent();
            On<Android>().SetToolbarPlacement(ToolbarPlacement.Bottom);
            On<Android>().SetIsSmoothScrollEnabled(true);
            
        }
        public async void validar()
        {
            if (Settings.Token == null)
            {
                await DisplayAlert("Error", "Tu sesion ya expiro", "Iniciar Sesión");
                await Navigation.PushAsync(new Login());
            }
            
        }
    }
}