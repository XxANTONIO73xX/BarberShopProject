﻿using BarberShop.Helpers;
using BarberShop.View.Sesion;
using BarberShop.ViewModel.VMMain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BarberShop.View.Main
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MasInformacion : ContentPage
    {
        public MasInformacion()
        {
            validar();
            InitializeComponent();
            BindingContext = new VMMasInformacion(Navigation);
        }
        public async void validar()
        {
            if (Settings.Token == null)
            {
                await DisplayAlert("Error", "Tu sesion ya expiro", "Iniciar Sesión");
                await Navigation.PushAsync(new Login());
            }

        }

        private async void Button_Clicked(object sender, EventArgs e)
        {
            bool respuesta = await DisplayAlert("¿Estas Seguro?", "¿Estas seguro de que deseas cerrar sesión?", "Sí", "No");
            if (respuesta)
            {
                Settings.Token = string.Empty;
                Settings.Id = string.Empty;
                Settings.IdBarberia = string.Empty;
                Settings.IdBarbero = string.Empty;
                Settings.Nombre = string.Empty;
                Settings.Apellidos = string.Empty;
                Settings.Correo = string.Empty;
                Settings.Telefono = string.Empty;
                await DisplayAlert("Cerrar Sesión", "Tu sesión ha sido cerrada", "OK");
                await Navigation.PopToRootAsync();
            }
        }
    }
}