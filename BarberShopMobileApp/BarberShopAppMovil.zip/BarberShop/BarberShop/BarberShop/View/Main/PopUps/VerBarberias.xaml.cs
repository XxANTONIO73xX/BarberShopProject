﻿using BarberShop.Helpers;
using BarberShop.Model;
using BarberShop.View.Sesion;
using BarberShop.ViewModel.VMMain.VMPopUps;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BarberShop.View.Main.PopUps
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class VerBarberias : ContentPage
    {
        public VerBarberias(Cita Cita)
        {
            validar();
            InitializeComponent();
            BindingContext = new VMVerBarberias(Navigation, Cita);
        }
        private void ImageButton_Clicked(object sender, EventArgs e)
        {
            Navigation.PopAsync();
        }

        public async void validar()
        {
            if (Settings.Token == null)
            {
                await DisplayAlert("Error", "Tu sesion ya expiro", "Iniciar Sesión");
                await Navigation.PushAsync(new Login());
            }

        }
    }
}