﻿using BarberShop.Helpers;
using BarberShop.Model;
using BarberShop.View.Sesion;
using BarberShop.ViewModel.VMMain.VMPopUps;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Rg.Plugins.Popup.Pages;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BarberShop.View.Main.PopUps
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class VerCita : PopupPage
    {
        public VerCita(int Id)
        {
            validar();
            InitializeComponent();
            BindingContext = new VMVerCita(Navigation, Id);
        }
        public async void validar()
        {
            if (Settings.Token == null)
            {
                await DisplayAlert("Error", "Tu sesion ya expiro", "Iniciar Sesión");
                await Navigation.PushAsync(new Login());
            }

        }

        public double VerticalTransition { get; set; }
        private async void PanGestureRecognizer_PanUpdated(object sender, PanUpdatedEventArgs e)
        {
            switch (e.StatusType)
            {
                case GestureStatus.Running:
                    if (e.TotalY > 0)
                    {
                        await GridPrincipal.TranslateTo(0, e.TotalY);
                        VerticalTransition = e.TotalY;
                    }
                    break;
                case GestureStatus.Completed:
                    if(VerticalTransition > 100)
                    {
                        await GridPrincipal.TranslateTo(0, 200);
                        if (PopupNavigation.Instance.PopupStack.Any())
                        {
                            await PopupNavigation.Instance.PopAsync();
                        }
                    }
                    else
                    {
                        await GridPrincipal.TranslateTo(0, e.TotalY);
                    }
                    break;
            }
        }

        private void ImageButton_Clicked(object sender, EventArgs e)
        {
            PopupNavigation.Instance.PopAsync();
        }
    }
}