﻿using BarberShop.ViewModel.VMMain.VMPopUps;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BarberShop.View.Main.PopUps
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class VerCortes : ContentPage
    {
        public VerCortes(int id)
        {
            InitializeComponent();
            BindingContext = new VMVerCortes(Navigation, id);
        }
    }
}