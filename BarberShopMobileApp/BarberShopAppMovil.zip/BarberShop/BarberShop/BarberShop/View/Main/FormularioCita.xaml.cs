﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BarberShop.Helpers;
using BarberShop.Model;
using BarberShop.View.Sesion;
using BarberShop.ViewModel.VMMain;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BarberShop.View.Main
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class FormularioCita : ContentPage
    {
        public FormularioCita( Cita Cita)
        {
            validar();
            InitializeComponent();
            BindingContext = new VMFormularioCita(Navigation,Cita);
        }
        public async void validar()
        {
            if (Settings.Token == null)
            {
                await DisplayAlert("Error", "Tu sesion ya expiro", "Iniciar Sesión");
                await Navigation.PushAsync(new Login());
            }

        }
    }
}