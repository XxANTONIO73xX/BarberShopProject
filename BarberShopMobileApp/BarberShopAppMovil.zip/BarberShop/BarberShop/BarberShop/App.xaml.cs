﻿using BarberShop.Helpers;
using BarberShop.View;
using BarberShop.View.Sesion;
using BarberShop.View.Main;
using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BarberShop
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
            MainPage = new NavigationPage(new Login());
        }

        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}
