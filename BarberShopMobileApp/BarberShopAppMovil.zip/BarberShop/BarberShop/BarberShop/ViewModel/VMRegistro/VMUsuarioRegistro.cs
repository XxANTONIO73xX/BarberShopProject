﻿using BarberShop.Helpers;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace BarberShop.ViewModel.VMMain
{
    public class VMUsuarioRegistro : BaseViewModel
    {
        #region VARIABLES
        string _Nombre;
        string _Apellidos;
        string _Correo;
        string _Telefono;
        string _Password;
        string _Verify;
        HttpClient client = new HttpClient();
        #endregion
        #region CONSTRUCTOR
        public VMUsuarioRegistro(INavigation navigation)
        {
            Navigation = navigation;
        }
        #endregion
        #region OBJETOS
        public string Nombre
        {
            get { return _Nombre; }
            set { SetValue(ref _Nombre, value); }
        }
        public string Apellidos
        {
            get { return _Apellidos; }
            set { SetValue(ref _Apellidos, value); }
        }
        
        public string Correo
        {
            get { return _Correo; }
            set { SetValue(ref _Correo, value); }
        }
        public string Telefono
        {
            get { return _Telefono; }
            set { SetValue(ref _Telefono, value); }
        }
        public string Password
        {
            get { return _Password; }
            set { SetValue(ref _Password, value); }
        }
        public string Verify
        {
            get { return _Verify; }
            set { SetValue(ref _Verify, value); }
        }
        #endregion
        #region PROCESOS
        public async Task GoBackAsync()
        {
            await Navigation.PopAsync();
        }
        public async Task RegistroAsync()
        {
            if(Password != Verify) { await DisplayAlert("Error", "Las contraseñas no coiciden", "OK"); return; }
            if(Nombre == null || Apellidos == null || Correo == null || Telefono == null || Password == null) { await DisplayAlert("Error", "No olvide llenar todos los espacios", "OK"); return; }
            var values = new Dictionary<string, string>
            {
                {"nombre", Nombre},
                {"apellidos", Apellidos},
                {"correo", Correo},
                {"telefono", Telefono},
                {"password", Password}
            };
            var content = new FormUrlEncodedContent(values);
            try
            {
                HttpResponseMessage responseMessage = await client.PostAsync("http://api.kikosbarbershop.online/public/cliente", content);
                string responseText = await responseMessage.Content.ReadAsStringAsync();
                JObject jObject = JObject.Parse(responseText);
                await DisplayAlert("¡Excelente!", "Hola, " + jObject.GetValue("nombre") + " has sido registrado correctamente", "Iniciar Sesión");
                await GoBackAsync();

            }
            catch (HttpRequestException ex)
            {
                await DisplayAlert("Error", ex.Message, "ok");
            }
        }
        public void ProcesoSimple()
        {

        }
        #endregion
        #region COMANDOS
        public ICommand GoBackAsyncCommand => new Command(async () => await GoBackAsync());
        public ICommand RegistroAsyncCommand => new Command(async () => await RegistroAsync());
        public ICommand ProcesoSimCommand => new Command(ProcesoSimple);
        #endregion
    }
}
