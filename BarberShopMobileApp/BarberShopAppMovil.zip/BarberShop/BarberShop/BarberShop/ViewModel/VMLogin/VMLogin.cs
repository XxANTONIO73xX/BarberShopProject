﻿using BarberShop.Helpers;
using BarberShop.View;
using BarberShop.View.Main;
using BarberShop.View.Registro;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace BarberShop.ViewModel.VMLogin
{
    public class VMLogin : BaseViewModel
    {
        #region VARIABLES
        string _User;
        string _Password;
        HttpClient client = new HttpClient();
        #endregion
        #region CONSTRUCTOR
        public VMLogin(INavigation navigation)
        {
            Navigation = navigation;
        }
        #endregion
        #region OBJETOS
        public string User
        {
            get { return _User; }
            set { SetValue(ref _User, value); }
        }
        public string Password
        {
            get { return _Password; }
            set { SetValue(ref _Password, value); }
        }
        #endregion
        #region PROCESOS
        public async Task LoginAsync()
        {
            var values = new Dictionary<string, string>
            {
                {"user",User},
                {"password",Password},
                {"tipo","cliente"}
            };
            var content = new FormUrlEncodedContent(values);
                
            HttpResponseMessage responseMessage = await client.PostAsync("http://api.kikosbarbershop.online/public/auth", content);
            string responseText = await responseMessage.Content.ReadAsStringAsync();
            JObject jObject = JObject.Parse(responseText);
            if (jObject.ContainsKey("error"))
            {
                await DisplayAlert("Error", "" + jObject.GetValue("error"), "OK");
                return;
            }
            Settings.Token = jObject.GetValue("token").ToString();
            jObject = JObject.Parse(jObject.GetValue("user").ToString()); //genero un objeto de user sacado del response
            Settings.Id = jObject.GetValue("id").ToString();
            Settings.Nombre = jObject.GetValue("nombre").ToString();
            Settings.Apellidos = jObject.GetValue("apellidos").ToString();
            Settings.Correo = jObject.GetValue("correo").ToString();
            Settings.Telefono = jObject.GetValue("telefono").ToString();
            await DisplayAlert("Data", "token->" + Settings.Token + " UserId->"+Settings.Id, "OK");
            await Navigation.PushAsync(new PageMenu());

            
        }
        public async Task RegistroAsync()
        {
            await Navigation.PushAsync(new UsuarioRegistro());
        }
        public void ProcesoSimple()
        {

        }
        #endregion
        #region COMANDOS
        public ICommand LoginAsyncCommand => new Command(async () => await LoginAsync());
        public ICommand RegistroAsyncCommand => new Command(async () => await RegistroAsync());
        public ICommand ProcesoSimCommand => new Command(ProcesoSimple);
        #endregion
    }
}
