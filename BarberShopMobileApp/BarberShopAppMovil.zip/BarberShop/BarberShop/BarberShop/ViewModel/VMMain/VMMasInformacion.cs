﻿using BarberShop.Helpers;
using BarberShop.Model;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace BarberShop.ViewModel.VMMain
{
    public class VMMasInformacion : BaseViewModel
    {
        #region VARIABLES
        HttpClient client = new HttpClient();
        #endregion
        #region CONSTRUCTOR
        public VMMasInformacion(INavigation navigation)
        {
            Navigation = navigation;
            Nombre = Settings.Nombre;
            Apellidos = Settings.Apellidos;
            Correo = Settings.Correo;
            Telefono = Settings.Telefono;
        }
        #endregion
        #region OBJETOS
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public string Correo { get; set; }
        public string Telefono { get; set; }
        #endregion
        #region PROCESOS
        public async Task ModificarUsuarioAsync()
        {
            var values = new Dictionary<string, string>
            {
                {"nombre", Nombre},
                {"apellidos", Apellidos},
                {"correo", Correo},
                {"telefono", Telefono}
            };
            var content = new FormUrlEncodedContent(values);

            var request = new HttpRequestMessage(HttpMethod.Post, "http://api.kikosbarbershop.online/public/cliente/update/" + Settings.Id);
            request.Headers.Add("Accept", "application/json");
            request.Headers.Add("token", Settings.Token);
            request.Content = content;
            HttpResponseMessage response = await client.SendAsync(request);
            string contentResponse = await response.Content.ReadAsStringAsync();
            JObject jObject = JObject.Parse(contentResponse);
            if (jObject.ContainsKey("error"))
            {
                await DisplayAlert("Error", "" + jObject.GetValue("error"), "OK");
                return;
            }
            jObject = JObject.Parse(jObject.GetValue("cliente").ToString());
            Settings.Nombre = jObject.GetValue("nombre").ToString();
            Settings.Apellidos = jObject.GetValue("apellidos").ToString();
            Settings.Correo = jObject.GetValue("correo").ToString();
            Settings.Telefono = jObject.GetValue("telefono").ToString();
            await DisplayAlert("Datos Guardados", "Los datos fueron guardados con exito", "OK");
        }
        public void ProcesoSimple()
        {

        }
        #endregion
        #region COMANDOS
        public ICommand ModificarUsuarioAsyncCommand => new Command(async () => await ModificarUsuarioAsync());
        public ICommand ProcesoSimCommand => new Command(ProcesoSimple);
        #endregion
    }
}