﻿using BarberShop.Helpers;
using BarberShop.Model;
using BarberShop.View.Main.PopUps;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace BarberShop.ViewModel.VMMain
{
    public class VMConsultarCitas : BaseViewModel
    {
        #region VARIABLES
        string _Texto;
        List<Cita> _Citas;
        string _IdCita;
        bool _isRefreshing;
        #endregion
        #region CONSTRUCTOR
        public VMConsultarCitas(INavigation navigation)
        {
            Navigation = navigation;
            getCitasAsync();
            RefreshCommand = new Command(async () => await LoadPublications());
        }
        #endregion
        #region OBJETOS
        public string Texto
        {
            get { return _Texto; }
            set { SetValue(ref _Texto, value); }
        }
        public List<Cita> Citas
        {
            get { return _Citas; }
            set { SetValue(ref _Citas, value); }
        }
        public string IdCita
        {
            get { return _IdCita; }
            set { SetValue(ref _IdCita, value); }
        }
        public bool IsRefreshing
        {
            get => _isRefreshing;
            set { _isRefreshing = value; OnPropertyChanged(); }
        }
        public ICommand RefreshCommand { private set; get; }
        #endregion
        #region PROCESOS
        public async void getCitasAsync()
        {
            var request = new HttpRequestMessage();
            request.Method = HttpMethod.Get;
            request.RequestUri = new Uri("http://api.kikosbarbershop.online/public/cliente_cita/" + Settings.Id);
            request.Headers.Add("Accept", "application/json");
            request.Headers.Add("token", Settings.Token);
            var client = new HttpClient();
            HttpResponseMessage response = await client.SendAsync(request);
            string content = await response.Content.ReadAsStringAsync();
            JObject jObject = JObject.Parse(content);
            if (jObject.ContainsKey("error"))
            {
                await DisplayAlert("Error", "" + jObject.GetValue("error"), "OK");
                return;
            }
            var resultado = JsonConvert.DeserializeObject<List<Cita>>(jObject.GetValue("citas").ToString());

            Citas = resultado;
        }
        public async Task getCitaAsync(int Id)
        {
            await PopupNavigation.Instance.PushAsync(new VerCita(Id));
        }
        public void ProcesoSimple()
        {

        }
        async Task LoadPublications()
        {
            // code omitted
            getCitasAsync();
            IsRefreshing = false;
        }
        #endregion
        #region COMANDOS
        public ICommand GetCitaAsyncCommand => new Command<int>(async (Id) => await getCitaAsync(Id));
        public ICommand ProcesoSimCommand => new Command(ProcesoSimple);
        #endregion
    }
}
