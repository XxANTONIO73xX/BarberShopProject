﻿using BarberShop.Helpers;
using BarberShop.Model;
using BarberShop.View;
using BarberShop.View.Main;
using BarberShop.View.Main.PopUps;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace BarberShop.ViewModel.VMMain
{
    public class VMFormularioCita : BaseViewModel
    {
        #region VARIABLES
        HttpClient client = new HttpClient();
        Cita _Cita;
        DateTime _Fecha;
        DateTime _MaxDate;
        DateTime _MinDate;
        TimeSpan _Hora;
        #endregion
        #region CONSTRUCTOR
        public VMFormularioCita(INavigation navigation, Cita Cita)
        {
            Navigation = navigation;
            this.Cita = Cita;
            if(Cita.Fecha != null) { this.Fecha = DateTime.Parse(Cita.Fecha); }
            if(Cita.Hora != null) { this.Hora = TimeSpan.Parse(Cita.Hora); }
            this.MinDate = DateTime.Now;
            this.MaxDate = new DateTime(DateTime.Now.Year, 12, 31);
        }
        #endregion
        #region OBJETOS
        public Cita Cita
        {
            get { return _Cita; }
            set { _Cita = value; }
        }
        public DateTime Fecha
        {
            get { return _Fecha; }
            set { _Fecha = value; }
        }
        public TimeSpan Hora
        {
            get { return _Hora; }
            set { _Hora = value; }
        }
        public DateTime MaxDate
        {
            get { return _MaxDate; }
            set { _MaxDate = value; }
        }
        public DateTime MinDate
        {
            get { return _MinDate; }
            set { _MinDate = value; }
        }
        #endregion
        #region PROCESOS
        public async Task getBarberiasAsync()
        {
            this.Cita.Fecha = Fecha.ToString("yyyy-MM-dd");
            this.Cita.Hora = "" + Hora;
            await Navigation.PushAsync(new VerBarberias(Cita));
        }
        public async Task GetBarberosAsync()
        {
            this.Cita.Fecha = Fecha.ToString("yyyy-MM-dd");
            this.Cita.Hora = "" + Hora;
            await Navigation.PushAsync(new VerBarberos(Cita));

        }
        public async Task GoBackAsync()
        {
            await Navigation.PushAsync(new PageMenu());
        }
        public async Task AgendarCitaAsync()
        {
            this.Cita.Fecha = Fecha.ToString("yyyy-MM-dd");
            this.Cita.Hora = "" + Hora;
            if (Cita.Barberia == null || Cita.Corte == null || Cita.Barbero == null || Cita.Hora == "00:00:00" || Cita.Fecha == "0001-01-01")
            {
                await DisplayAlert("Error", "Por favor llene todo el formulario", "OK");
                return;
            }
            if(Hora.Minutes > 00)
            {
                if(Hora.Minutes != 30)
                {
                    await DisplayAlert("Error", "Las cita se realizan con intervalos de 30 minutos por cita. tu hora: " + Hora.Hours + ":" + Hora.Minutes, "OK");
                    return;
                }
            }
            var values = new Dictionary<string, string>
            {
                {"idCliente", Settings.Id},
                {"idBarbero", Cita.Barbero.Id.ToString()},
                {"idCorte", Cita.Corte.Id.ToString()},
                {"idBarberia", Cita.Barberia.Id.ToString()},
                {"fecha", Cita.Fecha},
                {"hora", Cita.Hora},
                {"estado", "Pendiente"}
            };
            var content = new FormUrlEncodedContent(values);
            var request = new HttpRequestMessage(HttpMethod.Post, "http://api.kikosbarbershop.online/public/cita");
            request.Headers.Add("Accept", "application/json");
            request.Headers.Add("token", Settings.Token);
            request.Content = content;
            HttpResponseMessage response = await client.SendAsync(request);
            string contentResponse = await response.Content.ReadAsStringAsync();
            JObject jObject = JObject.Parse(contentResponse);
            if (jObject.ContainsKey("error"))
            {
                await DisplayAlert("Error", "" + jObject.GetValue("error"), "OK");
                return;
            }
            var resultado = JsonConvert.DeserializeObject<Cita>(jObject.GetValue("cita").ToString());
            await PopupNavigation.Instance.PushAsync(new VerCita(resultado.Id));
            await Navigation.PushAsync(new PageMenu());
        }
        public void ProcesoSimple()
        {

        }
        #endregion
        #region COMANDOS
        public ICommand getBarberiasAsyncCommand => new Command(async () => await getBarberiasAsync());
        public ICommand GetBarberosAsyncCommand => new Command(async () => await GetBarberosAsync());
        public ICommand GoBackAsyncCommand => new Command(async () => await GoBackAsync());
        public ICommand AgendarCitaAsyncCommand => new Command(async () => await AgendarCitaAsync());


        public ICommand ProcesoSimCommand => new Command(ProcesoSimple);
        #endregion
    }
}
