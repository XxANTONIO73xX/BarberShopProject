﻿using BarberShop.Helpers;
using BarberShop.Model;
using BarberShop.View.Main;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace BarberShop.ViewModel.VMMain
{
    public class VMAgendarCitas : BaseViewModel
    {
        #region VARIABLES
        string _Texto;
        List<Corte> _Cortes;
        #endregion
        #region CONSTRUCTOR
        public VMAgendarCitas(INavigation navigation)
        {
            Navigation = navigation;
            GetCorte();
        }
        #endregion
        #region OBJETOS
        public string Texto
        {
            get { return _Texto; }
            set { SetValue(ref _Texto, value); }
        }
        public List<Corte> Cortes
        {
            get { return _Cortes; }
            set { SetValue(ref _Cortes, value); }
        }
        #endregion
        #region PROCESOS
        public async void GetCorte()
        {
            var request = new HttpRequestMessage();
            request.Method = HttpMethod.Get;
            request.RequestUri = new Uri("http://api.kikosbarbershop.online/public/corte");
            request.Headers.Add("Accept", "application/json");
            request.Headers.Add("token", Settings.Token);
            var client = new HttpClient();
            HttpResponseMessage response = await client.SendAsync(request);
            string content = await response.Content.ReadAsStringAsync();
            JObject jObject = JObject.Parse(content);
            if (jObject.ContainsKey("error"))
            {
                await DisplayAlert("Error", "" + jObject.GetValue("error"), "OK");
                return;
            }
            var resultado = JsonConvert.DeserializeObject<List<Corte>>(jObject.GetValue("cortes").ToString());
            Cortes = resultado;
        }
        /*public async Task AbrirFormulario(Corte Corte)
        {
            await Navigation.PushAsync(new FormularioCita(Corte));
        }*/
        public void ProcesoSimple()
        {

        }
        #endregion
        #region COMANDOS 
        //public ICommand AbrirFormularioAsyncCommand => new Command<Corte>(async (Id) => await AbrirFormulario(Id));
        public ICommand ProcesoSimCommand => new Command(ProcesoSimple);
        #endregion
    }
}
