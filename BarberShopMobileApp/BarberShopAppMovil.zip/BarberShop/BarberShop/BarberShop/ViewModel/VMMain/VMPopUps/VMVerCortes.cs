﻿using BarberShop.Helpers;
using BarberShop.Model;
using BarberShop.View.Main.PopUps;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace BarberShop.ViewModel.VMMain.VMPopUps
{
    public class VMVerCortes : BaseViewModel
    {
        #region VARIABLES
        string _Texto;
        List<Corte> _Cortes;
        HttpClient client = new HttpClient();
        int IdCita;
        #endregion
        #region CONSTRUCTOR
        public VMVerCortes(INavigation navigation, int idCita)
        {
            Navigation = navigation;
            GetCorte();
            IdCita = idCita;
        }
        #endregion
        #region OBJETOS
        public string Texto
        {
            get { return _Texto; }
            set { SetValue(ref _Texto, value); }
        }
        public List<Corte> Cortes
        {
            get { return _Cortes; }
            set { SetValue(ref _Cortes, value); }
        }
        #endregion
        #region PROCESOS
        public async void GetCorte()
        {
            var request = new HttpRequestMessage();
            request.Method = HttpMethod.Get;
            request.RequestUri = new Uri("http://api.kikosbarbershop.online/public/corte");
            request.Headers.Add("Accept", "application/json");
            request.Headers.Add("token", Settings.Token);
            var client = new HttpClient();
            HttpResponseMessage response = await client.SendAsync(request);
            string content = await response.Content.ReadAsStringAsync();
            JObject jObject = JObject.Parse(content);
            if (jObject.ContainsKey("error"))
            {
                await DisplayAlert("Error", "" + jObject.GetValue("error"), "OK");
                return;
            }
            var resultado = JsonConvert.DeserializeObject<List<Corte>>(jObject.GetValue("cortes").ToString());
            Cortes = resultado;
        }
        /*public async Task AbrirFormulario(Corte Corte)
        {
            await Navigation.PushAsync(new FormularioCita(Corte));
        }*/
        public async Task CambiarCorteAsync(int Id)
        {
            var values = new Dictionary<string, string>
            {
                {"idCorte", ""+Id }
            };
            var content = new FormUrlEncodedContent(values);

            var request = new HttpRequestMessage(HttpMethod.Post, "http://api.kikosbarbershop.online/public/cita/update/" + IdCita);
            request.Headers.Add("Accept", "application/json");
            request.Headers.Add("token", Settings.Token);
            request.Content = content;
            HttpResponseMessage response = await client.SendAsync(request);
            string contentResponse = await response.Content.ReadAsStringAsync();
            JObject jObject = JObject.Parse(contentResponse);
            if (jObject.ContainsKey("error"))
            {
                await DisplayAlert("Error", "" + jObject.GetValue("error"), "OK");
                return;
            }
            await DisplayAlert("Exitoso", "Tu Corte se cambio correctamente", "OK");
            await PopupNavigation.Instance.PushAsync(new VerCita(IdCita));
            await Navigation.PopAsync();
        }
        #endregion
        #region COMANDOS 
        public ICommand CambiarCorteAsyncCommand => new Command<int>(async (Id) => await CambiarCorteAsync(Id));
        #endregion
    }
}
