﻿using BarberShop.Helpers;
using BarberShop.Model;
using BarberShop.View.Main;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace BarberShop.ViewModel.VMMain.VMPopUps
{
    public class VMVerBarberos : BaseViewModel
    {
        #region VARIABLES
        Cita _Cita;
        List<Barbero> _Barberos;
        HttpClient client = new HttpClient();
        #endregion
        #region CONSTRUCTOR
        public VMVerBarberos(INavigation navigation, Cita Cita)
        {
            Navigation = navigation;
            GetBarberosAsync();
            this.Cita = Cita;
        }
        #endregion
        #region OBJETOS
        public List<Barbero> Barberos
        {
            get { return _Barberos; }
            set { SetValue(ref _Barberos, value); }
        }
        public Cita Cita
        {
            get { return _Cita; }
            set { SetValue(ref _Cita, value); }
        }
        #endregion
        #region PROCESOS
        public async void GetBarberosAsync()
        {
            var request = new HttpRequestMessage();
            request.Method = HttpMethod.Get;
            request.RequestUri = new Uri("http://api.kikosbarbershop.online/public/barbero");
            request.Headers.Add("Accept", "application/json");
            request.Headers.Add("token", Settings.Token);
            HttpResponseMessage response = await client.SendAsync(request);
            string content = await response.Content.ReadAsStringAsync();
            JObject jObject = JObject.Parse(content);
            if (jObject.ContainsKey("error"))
            {
                await DisplayAlert("Error", "" + jObject.GetValue("error"), "OK");
                return;
            }
            var resultado = JsonConvert.DeserializeObject<List<Barbero>>(jObject.GetValue("barberos").ToString());

            Barberos = resultado;
        }
        public async Task SeleccionarBarberoAsyncrono(int id)
        {
            var request = new HttpRequestMessage(HttpMethod.Get, "http://api.kikosbarbershop.online/public/barbero/" + id);
            request.Headers.Add("Accept", "application/json");
            request.Headers.Add("token", Settings.Token);
            HttpResponseMessage response = await client.SendAsync(request);
            string content = await response.Content.ReadAsStringAsync();
            JObject jObject = JObject.Parse(content);
            if (jObject.ContainsKey("error"))
            {
                await DisplayAlert("Error", "" + jObject.GetValue("error"), "OK");
                return;
            }
            var resultado = JsonConvert.DeserializeObject<Barbero>(jObject.GetValue("barbero").ToString());
            this.Cita.Barbero = resultado;
            await Navigation.PushAsync(new FormularioCita(this.Cita));
        }
        public void ProcesoSimple()
        {

        }
        #endregion
        #region COMANDOS
        public ICommand SeleccionarBarberoAsyncronoCommand => new Command<int>(async (id) => await SeleccionarBarberoAsyncrono(id));
        public ICommand ProcesoSimCommand => new Command(ProcesoSimple);
        #endregion
    }
}
