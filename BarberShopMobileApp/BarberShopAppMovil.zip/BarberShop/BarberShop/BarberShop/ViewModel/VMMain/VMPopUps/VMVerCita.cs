﻿using BarberShop.Helpers;
using BarberShop.Model;
using BarberShop.View.Main.PopUps;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace BarberShop.ViewModel.VMMain.VMPopUps
{
    public class VMVerCita : BaseViewModel
    {
        #region VARIABLES
        string _Texto;
        Cita _Cita;
        int id;
        HttpClient client = new HttpClient();
        #endregion
        #region CONSTRUCTOR
        public VMVerCita(INavigation navigation, int Id)
        {
            Navigation = navigation;
            GetCita(Id);
            id = Id;
        }
        #endregion
        #region OBJETOS
        public string Texto
        {
            get { return _Texto; }
            set { SetValue(ref _Texto, value); }
        }
        public Cita Cita
        {
            get { return _Cita; }
            set { SetValue(ref _Cita, value); }
        }
        #endregion
        #region PROCESOS
        public async Task CancelarCitaAsync()
        {
            var values = new Dictionary<string, string>
            {
                {"estado", "Cancelado" }
            };
            var content = new FormUrlEncodedContent(values);

            var request = new HttpRequestMessage(HttpMethod.Post, "http://api.kikosbarbershop.online/public/cita/update/" + id);
            request.Headers.Add("Accept", "application/json");
            request.Headers.Add("token", Settings.Token);
            request.Content = content;
            HttpResponseMessage response = await client.SendAsync(request);
            string contentResponse = await response.Content.ReadAsStringAsync();
            JObject jObject = JObject.Parse(contentResponse);
            if (jObject.ContainsKey("error"))
            {
                await DisplayAlert("Error", "" + jObject.GetValue("error"), "OK");
                return;
            }
            await DisplayAlert("Que lastima...", "Tu cita ya fue cancelada, si deseas re agendar no olvides llamar", "OK");
            await PopupNavigation.Instance.PopAsync();
        }
        public async void GetCita(int Id)
        {
            var request = new HttpRequestMessage();
            request.Method = HttpMethod.Get;
            request.RequestUri = new Uri("http://api.kikosbarbershop.online/public/cita/" + Id);
            request.Headers.Add("Accept", "application/json");
            request.Headers.Add("token", Settings.Token);
            var client = new HttpClient();
            HttpResponseMessage response = await client.SendAsync(request);
            string content = await response.Content.ReadAsStringAsync();
            JObject jObject = JObject.Parse(content);
            if (jObject.ContainsKey("error"))
            {
                await DisplayAlert("Error", "" + jObject.GetValue("error"), "OK");
                return;
            }
            var resultado = JsonConvert.DeserializeObject<Cita>(jObject.GetValue("cita").ToString());
            this.Cita = resultado;
        }
        public async Task CambiarCorte()
        {
            await Navigation.PushAsync(new VerCortes(id));
            await PopupNavigation.Instance.PopAsync();
        }
        #endregion
        #region COMANDOS
        public ICommand CancelarCitaAsyncCommand => new Command(async () => await CancelarCitaAsync());
        public ICommand CambiarCorteAsyncCommand => new Command(async () => await CambiarCorte());
        #endregion
    }
}
