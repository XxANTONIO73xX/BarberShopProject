﻿using BarberShop.Model;
using Plugin.Settings;
using Plugin.Settings.Abstractions;

namespace BarberShop.Helpers
{
    public static class Settings
    {
        private const string _Token = "token";

        private const string _Id = "0";

        private const string _IdBarberia = "0";

        private const string _IdBarbero = "0";

        private const string _Nombre = "nombre";

        private const string _Apellidos = "apellidos";

        private const string _Correo = "correo";

        private const string _Telefono = "6666";

        private static readonly string _settingsDefaultToken = string.Empty;
        private static readonly string _settingsDefaultId = string.Empty;
        private static readonly string _settingsDefaultIdBarberia = string.Empty;
        private static readonly string _settingsDefaultIdBarbero = string.Empty;
        private static readonly string _settingsDefaultNombre = string.Empty;
        private static readonly string _settingsDefaultApellidos = string.Empty;
        private static readonly string _settingsDefaultCorreo = string.Empty;
        private static readonly string _settingsDefaultTelefono = string.Empty;

        private static ISettings AppSettings => CrossSettings.Current;

        public static string Token
        {
            get => AppSettings.GetValueOrDefault(_Token, _settingsDefaultToken);
            set => AppSettings.AddOrUpdateValue(_Token, value);
        }
        public static string Id
        {
            get => AppSettings.GetValueOrDefault(_Id, _settingsDefaultId);
            set => AppSettings.AddOrUpdateValue(_Id, value);
        }

        public static string IdBarberia
        {
            get => AppSettings.GetValueOrDefault(_IdBarberia, _settingsDefaultIdBarberia);
            set => AppSettings.AddOrUpdateValue(_IdBarberia, value);
        }
        public static string IdBarbero
        {
            get => AppSettings.GetValueOrDefault(_IdBarbero, _settingsDefaultIdBarbero);
            set => AppSettings.AddOrUpdateValue(_IdBarbero, value);
        }
        public static string Nombre
        {
            get => AppSettings.GetValueOrDefault(_Nombre, _settingsDefaultNombre);
            set => AppSettings.AddOrUpdateValue(_Nombre, value);
        }
        public static string Apellidos
        {
            get => AppSettings.GetValueOrDefault(_Apellidos, _settingsDefaultApellidos);
            set => AppSettings.AddOrUpdateValue(_Apellidos, value);
        }
        public static string Correo
        {
            get => AppSettings.GetValueOrDefault(_Correo, _settingsDefaultCorreo);
            set => AppSettings.AddOrUpdateValue(_Correo, value);
        }
        public static string Telefono
        {
            get => AppSettings.GetValueOrDefault(_Telefono, _settingsDefaultTelefono);
            set => AppSettings.AddOrUpdateValue(_Telefono, value);
        }

    }
}
